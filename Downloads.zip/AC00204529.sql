-----------------------------------------------------------------------------------------------------------------
--- Responsable: Isa�n Hern�ndez Hern�ndez
--- Fecha:		 Septiembre 2019
--- Descripcion: Url para consultas al servicio de Formalizacion
--- Aplicaci�n:  Surtimiento Seguros (Elektra.Negocio.Entidades.Seguros.dll)
-----------------------------------------------------------------------------------------------------------------

SET NOCOUNT ON
DECLARE @vcMsgError VARCHAR (60)
BEGIN TRAN  AC00204529

IF NOT EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 2)
BEGIN
	INSERT INTO dbo.CFGDetail (fcNameSection, fiIdKey, fcNameKey, fcValueKey)
	VALUES ('SurtimientoAlnova', 2, 'urlConsultaCte', 'http://localhost:9004/WSBAZCREDTAZ/BAZ/BazCredFormalizacion/ConsultarCteAlnova')
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al insertar el registro en CFGDetail'
		GOTO ERRORES
	END							
END

IF NOT EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 3)
BEGIN
	INSERT INTO dbo.CFGDetail (fcNameSection, fiIdKey, fcNameKey, fcValueKey)
	VALUES ('SurtimientoAlnova', 3, 'urlFormalizar', 'http://localhost:9004/WSBAZCREDTAZ/BAZ/BazCredFormalizacion/FormalizarPedido')
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al insertar el registro en CFGDetail'
		GOTO ERRORES
	END							
END

IF NOT EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 4)
BEGIN
	INSERT INTO dbo.CFGDetail (fcNameSection, fiIdKey, fcNameKey, fcValueKey)
	VALUES ('SurtimientoAlnova', 4, 'urlDomiciliar', 'http://localhost:9004/WSBAZCREDTAZ/BAZ/BazCredFormalizacion/DomiciliarPedido')
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al insertar el registro en CFGDetail'
		GOTO ERRORES
	END							
END
COMMIT TRAN AC00204529
SET NOCOUNT OFF
RETURN

ERRORES:
   ROLLBACK TRAN  AC00204529
   RAISERROR(@vcMsgError,18,1)
   SET NOCOUNT OFF
   RETURN
GO
