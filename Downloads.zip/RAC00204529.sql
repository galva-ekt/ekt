-----------------------------------------------------------------------------------------------------------------
--- Responsable: Isa�n Hern�ndez Hern�ndez
--- Fecha:		 Septiembre 2019
--- Descripcion: Reverso AC00204529
--- Aplicaci�n:  Surtimiento Seguros (Elektra.Negocio.Entidades.Seguros.dll)
-----------------------------------------------------------------------------------------------------------------

SET NOCOUNT ON
DECLARE @vcMsgError VARCHAR (60)
BEGIN TRAN  RAC00204529

IF EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 2)
BEGIN
	DELETE FROM dbo.CFGDetail
	WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 2
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al eliminar el registro en CFGDetail'
		GOTO ERRORES
	END							
END

IF EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 3)
BEGIN
	DELETE FROM dbo.CFGDetail
	WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 3
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al eliminar el registro en CFGDetail'
		GOTO ERRORES
	END							
END

IF EXISTS (SELECT fcNameSection FROM dbo.CFGDetail WITH (NOLOCK) WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 4)
BEGIN
	DELETE FROM dbo.CFGDetail
	WHERE fcNameSection = 'SurtimientoAlnova' AND fiIdKey = 4
	
	IF @@ERROR <> 0
	BEGIN
		SET @vcMsgError = 'Error al eliminar el registro en CFGDetail'
		GOTO ERRORES
	END							
END
   
COMMIT TRAN RAC00204529
SET NOCOUNT OFF
RETURN

ERRORES:
   ROLLBACK TRAN  RAC00204529
   RAISERROR(@vcMsgError,18,1)
   SET NOCOUNT OFF
   RETURN
GO
